name = input("")
name = name.replace(":)", "🙂")
name = name.replace(":(", "🙁")
print(name)
