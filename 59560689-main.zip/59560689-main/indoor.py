name = input("").lower()
print(name)

