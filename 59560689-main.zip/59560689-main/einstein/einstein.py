mass = int(input("m: "))
E = mass*(300000000**2)
print(f"E: {E}")
