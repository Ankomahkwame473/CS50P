import emoji
a = input("Input: ")
b = emoji.emojize(a, language="alias")
print(f"Output: {b}")
